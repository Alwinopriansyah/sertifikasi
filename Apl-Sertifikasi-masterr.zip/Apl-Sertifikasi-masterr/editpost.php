<?php


include 'config/database.php';
include 'config/config.php';
require 'library/uuid.php';
require 'library/hashtag.php';


$id = $_GET['id'];

$exec = mysqli_query($koneksi, "SELECT * FROM posts WHERE uuid='" . $id . "'");
$data = mysqli_fetch_array($exec);

if (!empty($_POST)) {

    $post = $_POST['post'];

    if (strlen($post) > 250) {
        header("location:dashboard.php?pesan=panjang");
        exit();
    } else if (strlen($post) <= 0) {
        header('location:dashboard.php?pesan=kosong');
        exit();
    }

    $targetFilePath = '';

    if (isset($_FILES['media'])) {
        $file = $_FILES['media'];

        // Informasi tentang file yang diunggah
        $fileName = $file['name'];
        $fileTmpName = $file['tmp_name'];
        $fileSize = $file['size'];
        $fileError = $file['error'];

        // Pindahkan file yang diunggah ke lokasi yang ditentukan
        $targetDirectory = 'uploads/'; // Ganti dengan direktori yang sesuai
        $targetFilePath = $targetDirectory . $fileName;

        if ($fileError === 0) {
            if (move_uploaded_file($fileTmpName, $targetFilePath)) {
                echo "File berhasil diunggah.";
            } else {
                echo "Terjadi kesalahan saat mengunggah file.";
            }
        } else {
            echo "Terjadi kesalahan saat mengunggah file: " . $fileError;
        }
    }
    $post_id = $id;

    $exec = mysqli_query($koneksi, "UPDATE posts SET post='" . $post . "', post_image='" . $targetFilePath . "',created='" . date('Y-m-d H:i:s') . "' WHERE uuid='" . $post_id . "'");
    echo mysqli_error($koneksi);

    $ArrTags = carihastag($post);
    if (count($ArrTags) > 0) {
        for ($i = 0; $i < count($ArrTags); $i++) {
            $tag_id = format_uuidv4();
            echo "count : " . $i . '<br>';
            $exec = mysqli_query($koneksi, 'SELECT * FROM tags WHERE name="' . strtolower($ArrTags[$i]) . '"');

            if (mysqli_num_rows($exec) <= 0) {
                $exec = mysqli_query($koneksi, 'INSERT INTO tags VALUES("' . $tag_id . '","' . strtolower($ArrTags[$i]) . '")');
            } else {
                $data = mysqli_fetch_assoc($exec);
                $tag_id = $data['tag_id'];
            }
            mysqli_query($koneksi, "INSERT INTO post_tags VALUES('" . $post_id . "','" . $tag_id . "')");
        }
    }

    header('location:' . $baseURL . 'dashboard.php');
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mari Gosip | Login</title>
    <link rel="stylesheet" href="<?= $baseURL ?>assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="<?= $baseURL ?>assets/css/font-awesome.min.css">
    <link rel="canonical" href="https://getbootstrap.com/docs/5.2/examples/pricing/">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>

<body>
    <!--    PEMBUKA NAVIGASI -->
    <nav class="navbar navbar-expand-lg navbar-light bg-light">
        <!-- Container wrapper -->
        <div class="container-fluid">
            <!-- Toggle button -->
            <button class="navbar-toggler" type="button" data-mdb-toggle="collapse" data-mdb-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <i class="fas fa-bars"></i>
            </button>

            <!-- Collapsible wrapper -->
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <!-- Navbar brand -->
                <a class="navbar-brand mt-2 mt-lg-0" href="#">
                    <img src="<?= $baseURL ?>assets/mdb-transaprent-noshadows.png" height="50" alt="MDB Logo" loading="lazy" />
                </a>
                <!-- Left links -->
                <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                    <li class="nav-item">
                        <a class="nav-link" href="#">
                            <h2>Dunia Gosip</h2>
                        </a>
                    </li>

                </ul>
                <!-- Left links -->
            </div>
            <!-- Collapsible wrapper -->

            <!-- Right elements -->
            <div class="d-flex align-items-center">
                <!-- Notifications -->
                <div class="dropdown">
                    <a class="text-reset me-3 dropdown-toggle hidden-arrow" href="#" id="navbarDropdownMenuLink" role="button" data-bs-toggle="dropdown" data-mdb-toggle="dropdown" aria-expanded="false">
                        <i class="fas fa-bell"></i>
                        <!-- <span class="badge rounded-pill badge-notification bg-danger">1</span> -->
                    </a>
                    <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdownMenuLink">
                        <li>
                            <a class="dropdown-item" href="dashboard.php">Dashboard</a>
                        </li>
                        <li>
                            <a class="dropdown-item" href="dashboard.php">Posting Statues</a>
                        </li>
                        <li>
                            <a class="dropdown-item" href="dashboard.php">Something else here</a>
                        </li>
                    </ul>
                </div>

                <!-- Avatar -->
                <div class="dropdown">
                    <a class="dropdown-toggle d-flex align-items-center hidden-arrow" href="#" id="navbarDropdownMenuAvatar" role="button" data-bs-toggle="dropdown" data-mdb-toggle="dropdown" aria-expanded="false">
                        <img src="<?= $baseURL ?>assets/2.webp" class="rounded-circle" height="25" alt="Black and White Portrait of a Man" loading="lazy" />
                    </a>
                    <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdownMenuAvatar">
                        <li>
                            <a class="dropdown-item" href="profile.php">My profile</a>
                        </li>
                        <li>
                            <a class="dropdown-item" href="profile.php">Settings</a>
                        </li>
                        <li>
                            <a class="dropdown-item" href="logout.php">Logout</a>
                        </li>
                    </ul>
                </div>
            </div>
            <!-- Right elements -->
        </div>
        <!-- Container wrapper -->
    </nav>
    <!-- PENUTUP NAVIGASI  -->

    <div class="container-fluid">
    </div>
    <section class="mt-3">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-md-10">
                    <div class="card">
                        <form action="" method="POST" enctype="multipart/form-data">
                            <textarea name="post" id="post" cols="25" rows="6" placeholder="What do you think?" style="resize: none;" class="form-control"><?= $data[2] ?></textarea>
                            <input type="file" name="media" id="" class="form-control">
                            <button type="submit" class="btn btn-info d-flex">Post</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </section>


</body>
<script src="https://code.jquery.com/jquery-3.7.0.js"></script>
<script src="<?= $baseURL ?>assets\js\sweetalert.js"></script>
<script src="<?= $baseURL ?>assets\js\bootstrap.bundle.min.js"></script>
<script src="https://code.jquery.com/jquery-3.7.0.js" integrity="sha256-JlqSTELeR4TLqP0OG9dxM7yDPqX1ox/HfgiSLBj8+kM=" crossorigin="anonymous"></script>


</html>