<?php
include 'config/config.php';
include 'config/database.php';

session_start();
if (!isset($_SESSION['email'])) {

    header("location:" . $baseURL . "index.php?pesan=belum_login");
}
if (!empty($_POST)) {
    $targetFilePath = '';

    if (isset($_FILES['media'])) {
        $file = $_FILES['media'];

        // Informasi tentang file yang diunggah
        $fileName = $file['name'];
        $fileTmpName = $file['tmp_name'];
        $fileSize = $file['size'];
        $fileError = $file['error'];

        // Pindahkan file yang diunggah ke lokasi yang ditentukan
        $targetDirectory = 'uploads/'; // Ganti dengan direktori yang sesuai
        $targetFilePath = $targetDirectory . $fileName;

        if ($fileError === 0) {
            if (move_uploaded_file($fileTmpName, $targetFilePath)) {
                echo "File berhasil diunggah.";
            } else {
                echo "Terjadi kesalahan saat mengunggah file.";
            }
        } else {
            echo "Terjadi kesalahan saat mengunggah file: " . $fileError;
        }
    }

    mysqli_query($koneksi, "UPDATE users SET name='" . $_POST['nama'] . "', keterangan='" . $_POST['bio'] . "', picture='" . $targetFilePath . "' WHERE uuid='" . $_SESSION['userId'] . "'");
}
$exec = mysqli_query($koneksi, "SELECT * FROM users WHERE uuid='" . $_SESSION['userId'] . "'");
$data = mysqli_fetch_array($exec);
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mari Gosip | Profile</title>
    <link rel="stylesheet" href="<?= $baseURL ?>assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="<?= $baseURL ?>assets/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">

</head>

<body>
      <!--    PEMBUKA NAVIGASI -->
      <nav class="navbar navbar-expand-lg navbar-light bg-light">
        <!-- Container wrapper -->
        <div class="container-fluid">
            <!-- Toggle button -->
            <button class="navbar-toggler" type="button" data-mdb-toggle="collapse" data-mdb-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <i class="fas fa-bars"></i>
            </button>

            <!-- Collapsible wrapper -->
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <!-- Navbar brand -->
                <a class="navbar-brand mt-2 mt-lg-0" href="#">
                    <img src="<?= $baseURL ?>assets/mdb-transaprent-noshadows.png" height="50" alt="MDB Logo" loading="lazy" />
                </a>
                <!-- Left links -->
                <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                    <li class="nav-item">
                        <a class="nav-link" href="#">
                            <h2>Dunia Gosip</h2>
                        </a>
                    </li>

                </ul>
                <!-- Left links -->
            </div>
            <!-- Collapsible wrapper -->

            <!-- Right elements -->
            <div class="d-flex align-items-center">
                <!-- Notifications -->
                <div class="dropdown">
                    <a class="text-reset me-3 dropdown-toggle hidden-arrow" href="#" id="navbarDropdownMenuLink" role="button" data-bs-toggle="dropdown" data-mdb-toggle="dropdown" aria-expanded="false">
                        <i class="fas fa-bell"></i>
                        <!-- <span class="badge rounded-pill badge-notification bg-danger">1</span> -->
                    </a>
                    <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdownMenuLink">
                        <li>
                            <a class="dropdown-item" href="dashboard.php">Dashboard</a>
                        </li>
                        <li>
                            <a class="dropdown-item" href="dashboard.php">Posting Statues</a>
                        </li>
                        <li>
                            <a class="dropdown-item" href="dashboard.php">Something else here</a>
                        </li>
                    </ul>
                </div>

                <!-- Avatar -->
                <div class="dropdown">
                    <a class="dropdown-toggle d-flex align-items-center hidden-arrow" href="#" id="navbarDropdownMenuAvatar" role="button" data-bs-toggle="dropdown" data-mdb-toggle="dropdown" aria-expanded="false">
                        <img src="<?= $baseURL ?>assets/2.webp" class="rounded-circle" height="25" alt="Black and White Portrait of a Man" loading="lazy" />
                    </a>
                    <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdownMenuAvatar">
                        <li>
                            <a class="dropdown-item" href="profile.php">My profile</a>
                        </li>
                        <li>
                            <a class="dropdown-item" href="profile.php">Settings</a>
                        </li>
                        <li>
                            <a class="dropdown-item" href="logout.php">Logout</a>
                        </li>
                    </ul>
                </div>
            </div>
            <!-- Right elements -->
        </div>
        <!-- Container wrapper -->
    </nav>
    <!-- PENUTUP NAVIGASI  -->
    <section>
        <div class="container-fluid p-5">
            <div class="row justify-content-center">
                <div class="col-md-4">
                    <img class="rounded-circle shadow-lg " style="max-width:15vw" src="<?= $baseURL . ($data[6] == "" ? "assets/img (19).webp" : $data[6]) ?>" alt="">
                </div>
                <div class="col-md-6">
                <div class="col-xl-8">
                <!-- Account details card-->
                <div class="card mb-4">
                    <div class="card-header">Account Details</div>
                    <h1>Biodata Saya</h1>
                    <div class="card-body">
                        <form>
                            <!-- Form Group (username)-->
                            <div class="mb-3">
                            
                                <label class="small mb-1" for="nama">Nama</label>
                                <h2><?= $data[5] ?></h2>
                            </div>
                            <div class="mb-3">
                                <label class="small mb-1" for="bio">Status</label>
                                <h5><?= $data[4] ?></h5>
                            </div>
                            </form>
                    </div>
                    <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#profile">
                                Ganti Bio
                            </button>
                </div>
            </div>
                </div>
                <div class="col-md-3">
                    <!-- Modal -->
                    <div class="modal fade" id="profile" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
                        <div class="modal-dialog">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title" id="staticBackdropLabel">Ganti Bio</h5>
                                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                </div>
                                <div class="modal-body">
                                    <form action="" method="post" enctype="multipart/form-data">
                                        <div class="mb-3">
                                            <label class="form-label" for="nama">Nama</label>
                                            <input type="text" name="nama" id="nama" class="form-control">
                                        </div>
                                        <div class="mb-3">
                                            <label class="form-label" for="bio">Masukan Status </label>
                                            <input type="text" name="bio" id="bio" class="form-control">
                                        </div>
                                        <div class="mb-3">
                                            <label class="form-label" for="foto">Foto</label>
                                            <input type="file" name="foto" id="foto" class="form-control">
                                        </div>
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                    <button type="submit" class="btn btn-primary">Simpan</button>
                                </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <script src="<?= $baseURL ?>assets/js/bootstrap.min.js"></script>

</body>

</html>