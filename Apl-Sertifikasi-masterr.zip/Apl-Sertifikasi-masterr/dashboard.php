<?php
include 'config/config.php';
include 'config/database.php';

session_start();
if (!isset($_SESSION['email'])) {
    header("location:" . $baseURL . "index.php?pesan=belum_login");
} ?>

<!DOCTYPE html>
<html lang="en">

<head>
<meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mari Gosip | Profile</title>
    <link rel="canonical" href="https://getbootstrap.com/docs/5.2/examples/pricing/">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link href="<?= $baseURL ?>assets\css\bootstrap.min.css" rel="stylesheet">
</head>

<body>
    <!--    PEMBUKA NAVIGASI -->
    <nav class="navbar navbar-expand-lg navbar-light bg-light">
        <!-- Container wrapper -->
        <div class="container-fluid">
            <!-- Toggle button -->
            <button class="navbar-toggler" type="button" data-mdb-toggle="collapse" data-mdb-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <i class="fas fa-bars"></i>
            </button>

            <!-- Collapsible wrapper -->
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <!-- Navbar brand -->
                <a class="navbar-brand mt-2 mt-lg-0" href="#">
                    <img src="<?= $baseURL ?>assets/mdb-transaprent-noshadows.png" height="50" alt="MDB Logo" loading="lazy" />
                </a>
                <!-- Left links -->
                <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                    <li class="nav-item">
                        <a class="nav-link" href="#">
                            <h2>Dunia Gosip</h2>
                        </a>
                    </li>

                </ul>
                <!-- Left links -->
            </div>
            <!-- Collapsible wrapper -->

            <!-- Right elements -->
            <div class="d-flex align-items-center">
                <!-- Notifications -->
                <div class="dropdown">
                    <a class="text-reset me-3 dropdown-toggle hidden-arrow" href="#" id="navbarDropdownMenuLink" role="button" data-bs-toggle="dropdown" data-mdb-toggle="dropdown" aria-expanded="false">
                        <i class="fas fa-bell"></i>
                        <!-- <span class="badge rounded-pill badge-notification bg-danger">1</span> -->
                    </a>
                    <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdownMenuLink">
                        <li>
                            <a class="dropdown-item" href="dashboard.php">Dashboard</a>
                        </li>
                        <li>
                            <a class="dropdown-item" href="dashboard.php">Posting Statues</a>
                        </li>
                        <li>
                            <a class="dropdown-item" href="dashboard.php">Something else here</a>
                        </li>
                    </ul>
                </div>

                <!-- Avatar -->
                <div class="dropdown">
                    <a class="dropdown-toggle d-flex align-items-center hidden-arrow" href="#" id="navbarDropdownMenuAvatar" role="button" data-bs-toggle="dropdown" data-mdb-toggle="dropdown" aria-expanded="false">
                        <img src="<?= $baseURL ?>assets/2.webp" class="rounded-circle" height="25" alt="Black and White Portrait of a Man" loading="lazy" />
                    </a>
                    <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdownMenuAvatar">
                        <li>
                            <a class="dropdown-item" href="profile.php">My profile</a>
                        </li>
                        <li>
                            <a class="dropdown-item" href="profile.php">Settings</a>
                        </li>
                        <li>
                            <a class="dropdown-item" href="logout.php">Logout</a>
                        </li>
                    </ul>
                </div>
            </div>
            <!-- Right elements -->
        </div>
        <!-- Container wrapper -->
    </nav>
    <!-- PENUTUP NAVIGASI  -->
    
    <section class="mt-3">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-md-10">
                <div class="panel-heading">
                    <h3 class="panel-title">Apa yang kamu pikirkan.?</h3>
                </div>
                    <div class="card">
                        <?php
                        if (isset($_GET['pesan'])) {
                            if ($_GET['pesan'] == "panjang") {
                                echo '<div class="alert alert-danger" role="alert">
                                   Postingan tidak boleh lebih dari 250 karakter!</div>';
                            } else if ($_GET['pesan'] == "kosong") {
                                echo '<div class="alert alert-danger" role="alert">
                                   Caption harus di isi!</div>';
                            }
                        }
                        ?>
                        <form action="posthandler.php" method="POST" enctype="multipart/form-data">
                            <textarea name="post" id="post" cols="25" rows="6" placeholder="Typing Your Mind..!" style="resize: none;" class="form-control"></textarea>
                            <input type="file" name="media" id="" class="form-control">
                            <button type="submit" class="btn btn-info d-flex">Kirim Postingan</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </section>

<!-- PEMBUKA COLOUMN COMENTAR  -->
<section style="background-color: #eee;">
        <div class="container my-5 py-5">
            <div class="row d-flex justify-content-center">
                <div class="col-md-12 col-lg-10 col-xl-8">
                    <div class="card">
                        <div class="card-body">
                        <input type="text" name="" id="search" class="form-control" placeholder="cari tags">
                            <div id="tagssearch">
                                <?php
                                // $exec = mysqli_query($koneksi, "SELECT * FROM `posts`");
                                $exec = mysqli_query($koneksi, "SELECT a.uuid, a.post, a.post_image, b.name, DATE_FORMAT(a.created, '%D %M %Y %H:%i:%s') as `readable` FROM `posts` a JOIN users b ON a.user_id = b.uuid ORDER BY a.created DESC;");
                                if (mysqli_num_rows($exec) > 0) {
                                    $data = mysqli_fetch_all($exec);
                                    foreach ($data as $key => $value) { ?>
                                        <div class="card mt-2">
                                            <div class="card-header align-items-center">
                                                <div class="row">
                                                    <div class="col-md-6">
                                                        <h6><?= $value[3] . ', ' . $value[4]  ?> </h6>
                                                    </div>
                                                    <div class="col-md-6 text-end">
                                                        <div class="dropdown">
                                                            <button class="btn" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                                                                <svg width="12" height="14" fill="currentColor" class="bi bi-three-dots-vertical" viewBox="0 0 16 16">
                                                                    <path d="M9.5 13a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0zm0-5a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0zm0-5a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0z" />
                                                                </svg>
                                                            </button>
                                                            <ul class="dropdown-menu dropdown-menu-dark bg-dark">
                                                                <li><a href="<?= $baseURL ?>editpost.php?id=<?= $value[0] ?>" class="dropdown-item">edit</a></li>
                                                                <li><a class="dropdown-item text-danger del" data-id="<?= $value[0] ?>">delete</a></li>
                                                            </ul>
                                                        </div>
                                                    </div>
                                                </div>

                                            </div>
                                            <div class="card-body">
                                                <p id="caption"><?= $value[1] ?></p>
                                                <div class="row justify-content-evenly">
                                                    <?= ($value[2] == 'uploads/' ? '' : ' <div class="col-md-4">
                                            <img src="' . $baseURL . $value[2] . '" alt="" style="max-width:20vw" class="shadow">
                                        </div>') ?>
                                                </div>
                                            </div>

                                            <div class="small d-flex justify-content-center">
                                                <a href="#!" class="d-flex align-items-center me-3">
                                                    <button type="button" class="btn btn-primary"><a class="btn d-flex " data-id="<?= $value[0] ?>"> <i class="far fa-thumbs-up me-5" aria-hidden="true"></i></a></button>
                                                    <!-- <button type="button" class="btn btn-primary"><i class="far fa-thumbs-up me-5"></i></button> -->
                                                </a>
                                                <a href="#!" class="d-flex align-items-center me-3">
                                                    <button type="button" class="btn btn-info"><a class="btn d-flex btn-info komen" data-id="<?= $value[0] ?>"> <i class="far fa-comment-dots me-5" aria-hidden="true"></i></a></button>
                                                </a>
                                                <a href="#!" class="d-flex align-items-center me-3">
                                                    <button type="button" class="btn btn-primary"><a class="btn d-flex "> <i class="fas fa-share me-5" aria-hidden="true"></i></a></button>
                                            </div>
                                        </div>
                                    <?php }
                                } else { ?>
                                    <div class="card mt-2">
                                        <div class="card-body">
                                            <p>No post available</p>
                                        </div>
                                    </div>
                                <?php }; ?>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- PENUTUP COLOUMN COMENTAR  -->

    <!-- Modal -->
    <div class="modal fade" id="modalkomen" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="staticBackdropLabel">Komentar</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>

                <div class="modal-body">
                    <div id="komentar" class="p-3"></div>
                    <form action="" id="addcomment">
                        <div class="input-group mb-3">
                            <input type="text" class="form-control" placeholder="Tambahkan komentar" name="comment" aria-label="Tambahkan komentar" aria-describedby="basic-addon2">
                            <div class="input-group-append">
                                <span class="input-group-text" id="basic-addon2"><button type="submit" class="kirim btn"><i class="fa-solid fa-paper-plane"></i></i></button></span>
                            </div>
                            <input type="hidden" name="post_id">
                        </div>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                </div>

            </div>
        </div>
    </div>

    <div class="modal fade" id="editcoment" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">

                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form action="" id="comment">
                        <div class="form-group mb-3">
                            <label for="caption" class="form-label">Caption</label>
                            <textarea class="form-control" name="comment" id="textcomment" cols="25" rows="10" style="resize: none;"></textarea>
                            <button type="submit" class="btn btn-secondary">Simpan</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</body>
<script src="https://code.jquery.com/jquery-3.7.0.js"></script>
<script src="<?= $baseURL ?>assets\js\sweetalert.js"></script>
<script src="<?= $baseURL ?>assets\js\bootstrap.bundle.min.js"></script>
<script src="https://code.jquery.com/jquery-3.7.0.js" integrity="sha256-JlqSTELeR4TLqP0OG9dxM7yDPqX1ox/HfgiSLBj8+kM=" crossorigin="anonymous"></script>

<script>
    $('.komen').click(function() {
        let comment_id = $(this).data("id");
        loadkomen(comment_id);
        $('input[name="post_id"]').val(comment_id);
        $('#modalkomen').modal('show');
    })

    function loadkomen(id) {

        $.ajax({
            url: '<?= $baseURL ?>loadcomment.php',
            type: 'POST',
            data: {
                id: id
            },
            success: function(response) {
                $('#komentar').html(response);
            }
        })
    }
    $('#addcomment').submit(function(event) {
        event.preventDefault();
        let FormData = $(this).serialize();

        $.ajax({
            url: '<?= $baseURL ?>addcomment.php',
            type: 'POST',
            data: FormData,
            success: function(data) {
                loadkomen($('input[name="post_id"]').val());
                $('input[name="comment"]').val('');
                console.log(FormData);
            }
        })
    })
    $('.del').on('click', function(event) {
        event.preventDefault();
        let id = $(this).data("id");
        Swal.fire({
            title: 'Apakah Anda Yakin?',
            text: "Postingan akan dihapus permanen!",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Ya',
            cancelButtonText: 'Tidak'
        }).then((result) => {
            if (result.isConfirmed) {
                $.ajax({
                    url: '<?= $baseURL ?>delpost.php?id=' + id,
                    type: "GET",
                    success: function(response) {
                        console.log(response);
                        window.location.reload();
                    }
                })
            }
        })
    })

    function editcom(el) {
        $.ajax({
            url: '<?= $baseURL ?>getdata.php?id=' + $(el).data('id'),
            type: 'GET',
            success: function(data) {
                data = JSON.parse(data);
                console.log(data);
                $('form#comment').attr('action', 'updatecomment.php?id=' + $(el).data("id"));
                $('textarea#textcomment').text(data.comment);
            }
        })
        $('#editcoment').modal('show');
    }
    $('.edit').on('click', function(event) {
        let id = $(this).data("id");
    })

    $('form#comment').submit(function(event) {
        event.preventDefault();
        let FormData = $(this).serialize();
        let url = $(this).attr('action');

        $.ajax({
            url: '<?= $baseURL ?>' + url,
            type: 'POST',
            data: FormData,
            success: function(response) {
                loadkomen($('input[name="post_id"]').val());
                $('#editcoment').modal('hide');

            }
        })
    })
    $('#search').keyup(function(event) {
        event.preventDefault();
        let value = $(this).val();
        $.ajax({
            url: '<?= $baseURL ?>search.php?key=#' + value,
            type: "GET",
            success: function(response) {
                $('#tagssearch').html(response);
            }
        })
    })
</script>

</html>