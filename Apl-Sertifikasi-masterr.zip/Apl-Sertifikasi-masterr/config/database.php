<?php

$host = 'localhost';
$username = 'root';
$password = '';
$db = 'sosmeddd';


$koneksi = mysqli_connect($host, $username, $password, $db);

if (!$koneksi)
    echo "Gagal menghubungkan ke database";
